public class MultiPilaCompraAlmacen {
}
